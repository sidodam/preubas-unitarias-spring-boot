package com.api.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreubasUnitariasSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreubasUnitariasSpringBootApplication.class, args);
	}

}
